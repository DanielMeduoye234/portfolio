
document.addEventListener('DOMContentLoaded', function () {
    const hamburger = document.querySelector('.hamburger');
    const mobileMenu = document.querySelector('.mobile-menu');
    const closeIcon = document.querySelector('.close-icon');

    // Open Mobile Menu
    hamburger.addEventListener('click', () => {
        mobileMenu.style.left = '0'; // Slide in
    });

    // Close Mobile Menu
    closeIcon.addEventListener('click', () => {
        mobileMenu.style.left = '-100%'; // Slide out
    });
});


/*About me Homepage*/

document.addEventListener("DOMContentLoaded", () => {
    const tabs = document.querySelectorAll(".tab");
    const contents = document.querySelectorAll(".content");

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove("active"));
            // Hide all content
            contents.forEach(content => content.classList.add("hidden"));

            // Add active class to clicked tab
            tab.classList.add("active");
            // Show the corresponding content
            const contentId = tab.getAttribute("data-content");
            document.getElementById(contentId).classList.remove("hidden");
        });
    });
});



//Floating Icon//

// Get the main floating contact icon and the container
const mainIcon = document.querySelector('.main-icon');
const floatingContact = document.querySelector('.floating-contact');

// Toggle the display of contact options on click
mainIcon.addEventListener('click', () => {
    if (floatingContact.classList.contains('active')) {
        // Trigger closing animation
        floatingContact.classList.remove('active');
        floatingContact.classList.add('closing');

        // Wait for the fade-out animation to complete before hiding
        setTimeout(() => {
            floatingContact.classList.remove('closing');
        }, 300); // Animation duration (0.3s)
    } else {
        // Trigger opening animation
        floatingContact.classList.add('active');
    }
});






// Get the button element
const scrollToTopBtn = document.getElementById("scrollToTopBtn");

// Show the button when scrolling down
window.addEventListener("scroll", () => {
  if (window.scrollY > 200) { // Adjust this value as needed
    scrollToTopBtn.style.display = "flex"; // Flex for centering the icon
  } else {
    scrollToTopBtn.style.display = "none";
  }
});

// Scroll to the top when the button is clicked
scrollToTopBtn.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth" // Adds a smooth scrolling effect
  });
});
